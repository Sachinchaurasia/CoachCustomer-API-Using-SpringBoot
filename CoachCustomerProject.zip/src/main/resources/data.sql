INSERT INTO coach (name) VALUES ('John Coach');
INSERT INTO coach (name) VALUES ('Mike Trainer');

INSERT INTO customer (height, weight, coach_id) VALUES (180, 75, 1);
INSERT INTO customer (height, weight, coach_id) VALUES (165, 60, 2);
