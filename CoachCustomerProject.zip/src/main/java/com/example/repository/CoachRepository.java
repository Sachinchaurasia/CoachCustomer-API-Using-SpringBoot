package com.example.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.example.entity.Coach;

public interface CoachRepository extends JpaRepository<Coach, Long> {}
