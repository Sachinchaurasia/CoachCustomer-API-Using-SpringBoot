package com.example.controller;

import org.springframework.web.bind.annotation.*;
import java.util.*;
import com.example.entity.Coach;
import com.example.repository.CoachRepository;

@RestController
@RequestMapping("/coach")
public class CoachController {

    private final CoachRepository repo;

    public CoachController(CoachRepository r){this.repo=r;}

    @GetMapping
    public List<Coach> all(){ return repo.findAll(); }

    @PostMapping
    public Coach add(@RequestBody Coach c){ return repo.save(c); }
}
