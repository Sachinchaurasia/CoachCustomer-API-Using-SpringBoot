package com.example.controller;

import org.springframework.web.bind.annotation.*;
import java.util.*;
import com.example.entity.*;
import com.example.repository.*;

@RestController
@RequestMapping("/customer")
public class CustomerController {
    private final CustomerRepository crepo;
    private final CoachRepository coachRepo;

    public CustomerController(CustomerRepository c, CoachRepository cr){
        this.crepo=c; this.coachRepo=cr;
    }

    @GetMapping
    public List<Customer> all(){ return crepo.findAll(); }

    @PostMapping
    public Customer add(@RequestBody Map<String,Object> body){
        Customer cust = new Customer();
        cust.setHeight((int) body.get("height"));
        cust.setWeight((int) body.get("weight"));
        Long coachId = Long.valueOf(body.get("coachId").toString());
        Coach coach = coachRepo.findById(coachId).orElse(null);
        cust.setCoach(coach);
        return crepo.save(cust);
    }
}
