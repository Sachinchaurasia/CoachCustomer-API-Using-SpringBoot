package com.example.entity;

import jakarta.persistence.*;

@Entity
public class Customer {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private int height;
    private int weight;

    @ManyToOne
    @JoinColumn(name="coach_id")
    private Coach coach;

    public Long getId(){return id;}
    public void setId(Long id){this.id=id;}

    public int getHeight(){return height;}
    public void setHeight(int h){this.height=h;}

    public int getWeight(){return weight;}
    public void setWeight(int w){this.weight=w;}

    public Coach getCoach(){return coach;}
    public void setCoach(Coach c){this.coach=c;}
}
