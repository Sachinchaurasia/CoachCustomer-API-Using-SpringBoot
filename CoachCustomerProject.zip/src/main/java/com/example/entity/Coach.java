package com.example.entity;

import jakarta.persistence.*;
import java.util.*;

@Entity
public class Coach {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;

    @OneToMany(mappedBy="coach")
    private List<Customer> customers = new ArrayList<>();

    public Long getId() { return id; }
    public void setId(Long id) { this.id=id; }
    public String getName(){return name;}
    public void setName(String n){this.name=n;}
}
